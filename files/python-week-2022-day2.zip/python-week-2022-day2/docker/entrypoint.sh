#!/bin/sh

set -e

# You can put other setup logic here
# Evaluating passed command:
eval "exec $@"