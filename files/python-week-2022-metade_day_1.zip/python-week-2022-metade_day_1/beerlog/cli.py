from .config import settings


def main():
    print("Hello from", settings.NAME)
